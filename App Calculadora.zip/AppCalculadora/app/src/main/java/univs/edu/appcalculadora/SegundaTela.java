package univs.edu.appcalculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class SegundaTela extends AppCompatActivity {

    private TextView txtOperacao;
    private TextView txtResultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_tela);


        txtOperacao = findViewById(R.id.txtOperacao);
        txtResultado = findViewById(R.id.txtResultado);

       String operacao = getIntent().getExtras().getString("operacao");
       double  resultado = getIntent().getExtras().getDouble("resultado");

       txtOperacao.setText(operacao);
       txtResultado.setText(String.valueOf(resultado));


    }




}